# BS_guangdong_1080_1920
互联网竖屏项目，自助终端项目，主要功能：人脸识别、扫码支付、订单选择、订单增、删、改、星星评论等，vue，vuex，vue-router、element-ui、axios等
