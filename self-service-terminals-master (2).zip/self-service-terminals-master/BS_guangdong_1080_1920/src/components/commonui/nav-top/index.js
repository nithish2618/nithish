import NavTop from './nav-top'

const navtop={
  install:function(Vue){
    Vue.component('nav-top',NavTop)
  }
};

export default navtop;