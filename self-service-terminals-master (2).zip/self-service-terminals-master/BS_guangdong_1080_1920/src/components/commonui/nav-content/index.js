import NavContent from './nav-content'

const navcontent={
  install:function(Vue){
    Vue.component('nav-content',NavContent)
  }
};

export default navcontent;
